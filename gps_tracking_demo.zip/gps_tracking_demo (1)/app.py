from flask import Flask, request, jsonify

app = Flask(__name__)

# Store latest location
device_location = {"lat": None, "lng": None}

@app.route('/update-location', methods=['POST'])
def update_location():
    data = request.json
    device_location["lat"] = data.get("lat")
    device_location["lng"] = data.get("lng")
    return jsonify({"status": "success", "message": "Location updated"})

@app.route('/get-location', methods=['GET'])
def get_location():
    return jsonify(device_location)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
